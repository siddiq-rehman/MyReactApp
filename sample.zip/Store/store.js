import { combineReducers, createStore,applyMiddleware } from 'redux';
import thunk from 'redux-thunk';

const dataReducer=function(state=[],action){
if(action.type==="data"){
    return [...state,{data: action.payload,point:action.date}]
}
return state;
}

const load={
    loading:0
}
const loadReducer=function(state={loading:"loaded"},action){
    if(action.type==="loading"){
        return Object.assign({},state,{loading:"loading...."})
    }
    else if(action.type==="loaded"){
        return Object.assign({},state,{loading:"loaded"})
    }
    return state;
}


const reducers=combineReducers({
    data:dataReducer,
    load:loadReducer
})

const middleWare=applyMiddleware(thunk);


export default createStore(reducers,middleWare);